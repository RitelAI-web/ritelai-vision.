# RitelAI Vision

Repository deployment package for the RitelAI Vision frontend and Supabase Edge Function `quick-service`.

## Contents
- `index.html` — website frontend.
- `supabase/functions/quick-service/index.ts` — Market Intelligence / AI NEWS Edge Function.
- `.github/workflows/pages.yml` — publishes the static frontend to GitHub Pages after Pages is enabled for the repository.
- `.github/workflows/supabase-deploy.yml` — deploys `quick-service` when repository secrets are configured.

## GitHub Pages
1. In the repository settings, enable Pages and select **GitHub Actions** as the source.
2. Push to `main`; the Pages workflow publishes `index.html`.
3. Configure a custom domain separately if desired.

## Supabase deployment
Add repository Actions secrets:
- `SUPABASE_ACCESS_TOKEN`
- `SUPABASE_PROJECT_REF`

If the Edge Function needs provider credentials, configure them as Supabase function secrets (never commit them):
- `OPENAI_API_KEY`
- Any market/calendar provider keys required by the function.

Then run the **Deploy Supabase quick-service** workflow or push changes under `supabase/functions/quick-service/`.

## Important integration notes
- The frontend currently contains the Supabase project URL and publishable/anon key from the supplied source. Confirm these refer to the intended project before production use.
- The frontend invokes the existing `quick-service` function.
- Preserve existing `quick-handler` and `smooth-action` functions; this repository package does not replace them.
- The chart summary panel can only display Entry / Stop Loss / Take Profit / indicator values when the existing `quick-handler` response provides those fields.
- GitHub Pages publishes the static frontend only. It does not deploy Supabase functions or verify live market feeds, OpenAI responses, or QRIS payments.

## Validation
Static syntax checks are not an end-to-end production test. After deployment, test the site URL, browser console, Supabase function logs, market/calendar responses, chart analysis, and payment flow before accepting real customers.
